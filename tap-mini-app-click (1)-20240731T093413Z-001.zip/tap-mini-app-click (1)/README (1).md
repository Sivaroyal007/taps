# tap-mini-app
Tap Mini App Clicker for Telegram - Copy Tapswap, Notcoin, Hamster | Tap To Earn Telegram

<img src="https://i.imgur.com/uJD5zmu.png" alt="Tap Mini App Telegram Clicker - Copy Tapswap, Blum, Hamster" data-canonical-src="https://i.imgur.com/uJD5zmu.png" style="max-width: 100%;">
Tap Mini App Clicker for Telegram - Copy Tapswap, Notcoin, Hamster
We create Clicker games in Mini App Telegram.

We can clone and customize popular crypto clicker games like Tapswap, Hamster and Notcoin, or create a hybrid that combines their best features!

Also in our portfolio there are ready-made clickers that we can quickly set up for you and launching such a game will take a short time.

Functions:

🤘 Learderboard - tap - Click for mine coins 
🚀 Skin - Daily rewards and Boosts 
🤝 Referrals - Invite friends and recieve rewards 
You are getting:

A configured bot that is already working
Basic functional (mine-tap / boosts / refferals / tasks)
Minor design adjustments (change styles / logos)
Source code
Example Clicker

You can try the starting version of the bot including the basic functionality: 
We can install ready-made solutions for you, or make you a unique clicker with a unique design.
Contact : https://t.me/chris_lev11

Web3Hub:
  We always work for results
  Attention to target audience
  Presence on the most important platforms of the crypto industry
  Our company Verified Bybit,OKX, Pinksale & OKX Partner



Setup:
-------------
API.

Step 1: Create a new Telegram Bot and get the bot token and add it to the api server.

Step 2: Create a Realtime Database on Firebase and add it to adminsdk-firebase.json
https://console.firebase.google.com/

Run: npm run dev

------------------
Mini app client .

copy file .env.example to .env

Run: npm run start





Donate

Ton : UQB1IEqMQo_l1xRCU02D7FPgKdqLZNl8dDwJWOsAyRXad3YC

BSC, ETH : 0x1B22C7bD50C7807c7642f4D0Ec732fC16B278789