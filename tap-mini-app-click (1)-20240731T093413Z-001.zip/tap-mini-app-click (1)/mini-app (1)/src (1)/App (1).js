

// import React, { useState, useEffect } from 'react';
// import logo from './logo.svg';
// import CoinApp from './components/CoinApp';
// import { CssBaseline, ThemeProvider, createTheme } from '@mui/material';
// import axios from 'axios';
// import { BASE_API_URL } from "./config/index";
// import './App.css';
// import './css/customStyle.css';

// const theme = createTheme();
// const telApp = window.Telegram.WebApp;
// const isPhone = window.innerWidth < 600;

// function App() {
//   const [userData, setUserData] = useState(null);
//   const [profileUrl, setProfileUrl] = useState(null);
//   const [pointCount, setPointCount] = useState(0);
//   const [isTelegramMiniApp, setIsTelegramMiniApp] = useState(false);
//   const [miningInfo, setMiningInfo] = useState({
//     status: 'idle',
//     perClick: 2,
//     limit: 2000,
//     max: 2000,
//   });

//   useEffect(() => {
//     telApp.ready();
//     init();
//   }, []);

//   useEffect(() => {
//     if (userData) {
//       getUserProfile();
//       handleSignUp();
//       handleMiningInfo();
//     }
//   }, [userData]);

//   const init = () => {
//     const search = window.Telegram.WebApp.initData;
//     let data = null;

//     if (search) {
//       const converted = JSON.parse('{"' + search.replace(/&/g, '","').replace(/=/g, '":"') + '"}', (key, value) => {
//         return key === "" ? value : decodeURIComponent(value);
//       });
//       data = JSON.parse(converted.user);
//     } else {
//       data = {
//         "id": 1887509957,
//         "first_name": "Its Justin",
//         "last_name": "",
//         "username": "P2P_JS",
//         "language_code": "en",
//         "is_premium": true,
//         "allows_write_to_pm": true
//       };
//     }

//     if (data) {
//       setUserData(data);
//       setIsTelegramMiniApp(true);
//     } else {
//       setIsTelegramMiniApp(false);
//     }
//   };
//   const getUserProfile = async () => {
//     if (!userData || !userData.id) return;
  
//     try {
//       const { data: profileData } = await axios.get(`https://api.telegram.org/bot${process.env.REACT_APP_TELEGRAM_BOT_TOKEN}/getUserProfilePhotos?user_id=${userData.id}`);
//       console.log('Profile Data:', profileData); // Log profileData here
//       const fileId = profileData.result.photos[0][2].file_id;
//       const { data: fileData } = await axios.get(`https://api.telegram.org/bot${process.env.REACT_APP_TELEGRAM_BOT_TOKEN}/getFile?file_id=${fileId}`);
//       const filePath = fileData.result.file_path;
  
//       setProfileUrl(`https://api.telegram.org/file/bot${process.env.REACT_APP_TELEGRAM_BOT_TOKEN}/${filePath}`);
//     } catch (error) {
//       console.error('Error fetching user profile:', error);
//     }
//   };
  
//   // const getUserProfile = async () => {
//   //   if (!userData || !userData.id) return;

//   //   try {
//   //     const { data: profileData } = await axios.get(`https://api.telegram.org/bot${process.env.REACT_APP_TELEGRAM_BOT_TOKEN}/getUserProfilePhotos?user_id=${userData.id}`);
//   //     const fileId = profileData.result.photos[0][2].file_id;
//   //     const { data: fileData } = await axios.get(`https://api.telegram.org/bot${process.env.REACT_APP_TELEGRAM_BOT_TOKEN}/getFile?file_id=${fileId}`);
//   //     const filePath = fileData.result.file_path;

//   //     setProfileUrl(`https://api.telegram.org/file/bot${process.env.REACT_APP_TELEGRAM_BOT_TOKEN}/${filePath}`);
//   //   } catch (error) {
//   //     console.error('Error fetching user profile:', error);
//   //   }
//   // };

//   const handleMiningInfo = () => {
//     if (!userData || !userData.id) return;

//     axios.get(`${BASE_API_URL}user/${userData.id}`)
//       .then((response) => {
//         console.log('Mining Info Response:', response.data);
//         if (response.data && 'points' in response.data) {
//           setPointCount(response.data.points);
//         }
//         if (response.data && 'limit' in response.data) {
//           setMiningInfo(prevMiningInfo => ({
//             ...prevMiningInfo,
//             limit: response.data.limit
//           }));
//         }
//       })
//       .catch((error) => console.error('Mining Info Error:', error));
//   };

//   const handleSignUp = () => {
//     if (!userData || !userData.id) return;

//     axios.post(`${BASE_API_URL}signup`, {
//       userId: userData.id,
//       username: userData.username,
//       firstname: userData.first_name,
//       lastname: userData.last_name || 'null',
//     })
//     .then(response => console.log('Signup Response:', response.data))
//     .catch(error => console.error('Signup Error:', error));
//   };

//   return (
//     <div className="App">
//       {isPhone && isTelegramMiniApp ?
//         <ThemeProvider theme={theme}>
//           <CoinApp
//             userData={userData}
//             profileUrl={profileUrl}
//             telApp={telApp}
//             userId={userData.id}
//             pointCount={pointCount}
//             setPointCount={setPointCount}
//             miningInfo={miningInfo}
//             setMiningInfo={setMiningInfo}
//           />
//         </ThemeProvider>
//         :
//         <div style={{ height: '110vh' }}>
//           <h3 style={{ textAlign: 'center', background: 'rgb(216 215 215 / 42%)', display: 'inline-flex', padding: '20px', marginTop: '40vh', borderRadius: '20px' }}>
//             You need to open with Telegram bot!
//           </h3>
//           <h3>
//             <a href='https://t.me/sr423bot' style={{ textDecoration: 'none', color: 'darkmagenta' }}>
//               <img style={{ verticalAlign: 'middle', marginBottom: '16px' }} width="70" height="70" src="https://img.icons8.com/3d-fluency/94/robot-1.png" alt="robot-1" />
//               <span> Go to testbot </span>
//             </a>
//           </h3>
//         </div>
//       }
//     </div>
//   );
// }

// export default App;
import React, { useState, useEffect } from 'react';
import logo from './logo.svg';
import CoinApp from './components/CoinApp';
import { CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import axios from 'axios';
import { BASE_API_URL } from "./config/index";
import './App.css';
import './css/customStyle.css';

const theme = createTheme();
const telApp = window.Telegram.WebApp;
const isPhone = window.innerWidth < 600;

function App() {
  const [userData, setUserData] = useState(null);
  const [profileUrl, setProfileUrl] = useState(null);
  const [pointCount, setPointCount] = useState(0);
  const [isTelegramMiniApp, setIsTelegramMiniApp] = useState(false);
  const [miningInfo, setMiningInfo] = useState({
    status: 'idle',
    perClick: 2,
    limit: 2000,
    max: 2000,
  });

  useEffect(() => {
    telApp.ready();
    init();
  }, []);

  useEffect(() => {
    if (userData) {
      getUserProfile();
      handleSignUp();
      handleMiningInfo();
    }
  }, [userData]);

  const init = () => {
    const search = window.Telegram.WebApp.initData;

    if (search) {
      const converted = JSON.parse('{"' + search.replace(/&/g, '","').replace(/=/g, '":"') + '"}', (key, value) => {
        return key === "" ? value : decodeURIComponent(value);
      });
      const data = JSON.parse(converted.user);

      if (data) {
        setUserData(data);
        setIsTelegramMiniApp(true);
      } else {
        setIsTelegramMiniApp(false);
        console.error('Failed to parse user data from Telegram Web App.');
      }
    } else {
      setIsTelegramMiniApp(false);
      console.error('Telegram Web App data is not available.');
    }
  };

  const getUserProfile = async () => {
    if (!userData || !userData.id) return;

    try {
      const { data: profileData } = await axios.get(`https://api.telegram.org/bot${process.env.REACT_APP_TELEGRAM_BOT_TOKEN}/getUserProfilePhotos?user_id=${userData.id}`);
      const fileId = profileData.result.photos[0][2].file_id;
      const { data: fileData } = await axios.get(`https://api.telegram.org/bot${process.env.REACT_APP_TELEGRAM_BOT_TOKEN}/getFile?file_id=${fileId}`);
      const filePath = fileData.result.file_path;

      setProfileUrl(`https://api.telegram.org/file/bot${process.env.REACT_APP_TELEGRAM_BOT_TOKEN}/${filePath}`);
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const handleMiningInfo = () => {
    if (!userData || !userData.id) return;

    axios.get(`${BASE_API_URL}user/${userData.id}`)
      .then((response) => {
        if (response.data && 'points' in response.data) {
          setPointCount(response.data.points);
        }
        if (response.data && 'limit' in response.data) {
          setMiningInfo(prevMiningInfo => ({
            ...prevMiningInfo,
            limit: response.data.limit
          }));
        }
      })
      .catch((error) => console.error('Mining Info Error:', error));
  };

  const handleSignUp = () => {
    if (!userData || !userData.id) return;

    axios.post(`${BASE_API_URL}signup`, {
      userId: userData.id,
      username: userData.username,
      firstname: userData.first_name,
      lastname: userData.last_name || 'null',
    })
    .then(response => console.log('Signup Response:', response.data))
    .catch(error => console.error('Signup Error:', error));
  };

  return (
    <div className="App">
      {isPhone && isTelegramMiniApp ?
        <ThemeProvider theme={theme}>
          <CoinApp
            userData={userData}
            profileUrl={profileUrl}
            telApp={telApp}
            userId={userData.id}
            pointCount={pointCount}
            setPointCount={setPointCount}
            miningInfo={miningInfo}
            setMiningInfo={setMiningInfo}
          />
        </ThemeProvider>
        :
        <div style={{ height: '110vh' }}>
          <h3 style={{ textAlign: 'center', background: 'rgb(216 215 215 / 42%)', display: 'inline-flex', padding: '20px', marginTop: '40vh', borderRadius: '20px' }}>
            You need to open with Telegram bot!
          </h3>
          <h3>
            <a href='https://t.me/sr423bot' style={{ textDecoration: 'none', color: 'darkmagenta' }}>
              <img style={{ verticalAlign: 'middle', marginBottom: '16px' }} width="70" height="70" src="https://img.icons8.com/3d-fluency/94/robot-1.png" alt="robot-1" />
              <span> Go to testbot </span>
            </a>
          </h3>
        </div>
      }
    </div>
  );
}

export default App;
